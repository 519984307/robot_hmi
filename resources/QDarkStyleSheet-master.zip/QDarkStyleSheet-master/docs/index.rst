.. QDarkStyle documentation master file, created by
   sphinx-quickstart on Tue May  8 14:23:26 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to QDarkStyle's documentation!
======================================

.. toctree::
   :maxdepth: 2

   readme.rst
   screenshots.rst
   known_issues.rst
   contributing.rst
   color_reference.rst
   reference/modules.rst
   scripts/modules.rst
   changes.rst
   authors.rst
   license.rst
   code_of_conduct.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

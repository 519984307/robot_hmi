qdarkstyle.light.style\_rc module
=================================

.. automodule:: qdarkstyle.light.style_rc
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
